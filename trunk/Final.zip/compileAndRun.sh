#!/bin/bash

################################################################################
# You need the boost library for this program to compile and run.
#  sudo apt-get install libboost1.40-all-dev
# This is tested for Ubuntu 10.04 and 10.10 (but with 1.42).

# Go into the src folder.
cd src

# Check which spectrum of boards to use...
if [ $# == 0 ]; then
	FROM=1
	TO=136
elif [ $# == 1 ]; then
	FROM=1
	TO=$1
elif [ $# == 2 ]; then
	FROM=$1
	TO=$2
else
	echo "Wut?" 1>&2
	exit -1
fi

# ..., compile...
make

# ... and let the fun begin. :-)
for i in $(seq $FROM $TO); do
	./sokoban $i
done

exit 0
