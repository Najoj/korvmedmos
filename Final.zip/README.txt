Hello. Welcome to the README.txt.

We named our player Jens. This is what you will see in the code.

The number of total pages in the PDF exceeds 10, but this is due to LaTeX. We first wrote it in Google Docs, and there it was a bit shorter. LaTeX also ads empty pages.

In order to run the code you will need to install Boost C++ library. In Ubuntu
10.04 you do this by
 $  sudo apt-get install libboost1.40-all-dev
aswell as having g++.

In order to compile the code you should just type
 $  make
and then to run
 $  ./sokoban i
where i is the board you would want to solve.

You could also use our server.bash script. Run as
 $ ./server i | ./sokoban
or 
 $ ./server boards i | ./sokoban
if you have a file with boards on the format given in the file "banor". That is deafault when no other file is specified.

In main.cpp you can change the number of allowed iterations on row 186. If you have alot of RAM you can have a great value, if not you can stick with 20 000 000. This might even solve more boards, so if you have 4 GB you can change this to 30 000 000 or even 40 000 000.

The compileAndRun.bash script you iterate through all 136 levels. Some will take more than 1 minutes. If you want to you can use the timelimit.bash script in order to kill the program sokoban after 1 minute. This will fail if you run several processes named sokoban at the same time.

-- Best wishes from Johans hjältar.

Here are MD5SUMs:
a70651e92f511c70718a55483d525e12  compileAndRun.sh
766ffa95c57b7a561b8ce075f20e8319  report-ai10-groupjohanshjaeltar.pdf
10da481376c7d5eb8e324a980ae2979b  src/banor
734175b6e9feabb3f73ad6a458b8b8e5  src/Board.hpp
10200a2bff2756eeb9b300675b0ee564  src/boxlocks.hpp
39408a9db8bdb69169f00f77b66db2c2  src/client.hpp
eda7586180e56d82139e7df4d303dce4  src/common.hpp
758a3a842744cd267c09055ae2aa34c7  src/heuristics.hpp
2435a45a266167f28889555ca90bf013  src/main.cpp
37d812b36b25ae75980bd3d103968cab  src/Makefile
4e9fc7636177972bb871ccbaff3e247c  src/node.hpp
66f1fbad1373c4e7f1eeebc34cc6ef0f  src/rules.cpp
456f48254f00daf2ea77144614e57b64  src/rules.hpp
d0b87809e454ed8630583de3556ab5a4  src/server.bash
6f6198d31e64949d888436f291e2e033  src/testScript.bash
ff400a397aa8a7f507e14707bb4b0368  src/timelimit.bash
